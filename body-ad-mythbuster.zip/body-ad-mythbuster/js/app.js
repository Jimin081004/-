/**
 * app.js
 * ------------------------------------------------------------------
 * 인체 생리 시뮬레이터의 전체 동작을 담당합니다.
 * devices.js 가 먼저 로드되어 전역 DEFAULT_DEVICES 배열을 제공한다고
 * 가정합니다.
 */

(function () {
  "use strict";

  /* ------------------------------------------------------------------ */
  /* 기관 메타데이터: SVG 안의 data-organ id 와 1:1로 대응합니다.          */
  /* origin 은 body-stage.zoomed 상태일 때 CSS transform-origin(%) 값.   */
  /* ------------------------------------------------------------------ */
  const ORGAN_META = {
    brain: { label: "뇌", origin: "50% 9%", desc: "신경전달물질과 수용체가 작용하는 곳. 수면·각성·인지에 관여합니다." },
    skin: { label: "피부(얼굴)", origin: "50% 13%", desc: "표피와 진피로 이뤄져 있고, 빛·화장품 성분이 처음 만나는 곳입니다." },
    liver: { label: "간", origin: "38% 30%", desc: "흡수된 성분을 가장 먼저 대사해 몸에 맞게 분해·해독하는 장기입니다." },
    stomach: { label: "위", origin: "64% 30%", desc: "먹은 것이 잘게 분해되고 일부 성분이 흡수되기 시작하는 곳입니다." },
    intestine: { label: "소장·대장", origin: "50% 41%", desc: "영양분 흡수의 대부분이 일어나고, 흡수되지 않은 것은 장내세균의 먹이가 됩니다." },
    kidney: { label: "신장", origin: "50% 34%", desc: "혈액을 걸러 대사되고 남은 성분과 노폐물을 소변으로 배출합니다." },
  };

  const CUSTOM_DEVICES_KEY = "bam_customDevices";
  const SEQ_AUTOPLAY_MS = 3600;

  /* ------------------------------------------------------------------ */
  /* 상태                                                                */
  /* ------------------------------------------------------------------ */
  let currentDeviceId = null;
  let currentMode = "compare"; // "compare" | "sequential"
  let seqIndex = 0;
  let seqTimer = null;

  /* ------------------------------------------------------------------ */
  /* DOM 참조                                                            */
  /* ------------------------------------------------------------------ */
  const $ = (sel) => document.querySelector(sel);
  const el = {
    deviceList: $("#device-list"),
    bodyStage: $("#body-stage"),
    detailFx: $("#detail-fx"),
    organLegend: $("#organ-legend"),
    organHint: $("#organ-hint"),
    dossierEmpty: $("#dossier-empty"),
    dossierContent: $("#dossier-content"),
    deviceTitle: $("#device-title"),
    deviceCategory: $("#device-category"),
    modeBtns: document.querySelectorAll(".mode-btn"),
    panelCompare: $("#panel-compare"),
    panelSequential: $("#panel-sequential"),
    textAd: $("#text-ad"),
    textReal: $("#text-real"),
    textWarn: $("#text-warn"),
    seqIndex: $("#seq-index"),
    seqTotal: $("#seq-total"),
    seqType: $("#seq-type"),
    seqLabel: $("#seq-label"),
    seqText: $("#seq-text"),
    seqDots: $("#seq-dots"),
    seqPrev: $("#seq-prev"),
    seqNext: $("#seq-next"),
    seqPlay: $("#seq-play"),
    btnAddDevice: $("#btn-add-device"),
    modalAdd: $("#modal-add"),
    formAdd: $("#form-add"),
    btnCancelAdd: $("#btn-cancel-add"),
    btnExport: $("#btn-export"),
    btnImport: $("#btn-import"),
    fileImport: $("#file-import"),
    btnIntro: $("#btn-intro"),
    modalIntro: $("#modal-intro"),
    btnCloseIntro: $("#btn-close-intro"),
  };

  /* ------------------------------------------------------------------ */
  /* localStorage 헬퍼                                                   */
  /* ------------------------------------------------------------------ */
  function loadCustomDevices() {
    try {
      const raw = localStorage.getItem(CUSTOM_DEVICES_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      console.warn("커스텀 기기 불러오기 실패", e);
      return [];
    }
  }

  function saveCustomDevices(arr) {
    try {
      localStorage.setItem(CUSTOM_DEVICES_KEY, JSON.stringify(arr));
    } catch (e) {
      console.warn("커스텀 기기 저장 실패", e);
    }
  }

  function getAllDevices() {
    return [...DEFAULT_DEVICES, ...loadCustomDevices()];
  }

  function isCustomId(id) {
    return loadCustomDevices().some((d) => d.id === id);
  }

  function findDevice(id) {
    return getAllDevices().find((d) => d.id === id) || null;
  }

  /* ------------------------------------------------------------------ */
  /* 기기 목록 렌더링                                                     */
  /* ------------------------------------------------------------------ */
  function renderDeviceList() {
    const devices = getAllDevices();
    el.deviceList.innerHTML = "";

    devices.forEach((device) => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "device-item" + (device.id === currentDeviceId ? " active" : "");
      btn.setAttribute("role", "option");
      btn.setAttribute("aria-selected", device.id === currentDeviceId ? "true" : "false");
      btn.dataset.id = device.id;

      btn.innerHTML =
        '<span class="emoji">' + escapeHtml(device.emoji || "🧪") + "</span>" +
        '<span class="meta"><span class="name">' + escapeHtml(device.name) + '</span>' +
        '<span class="cat">' + escapeHtml(device.category || "기타") + "</span></span>";

      btn.addEventListener("click", () => selectDevice(device.id));

      if (isCustomId(device.id)) {
        const del = document.createElement("button");
        del.type = "button";
        del.className = "del";
        del.title = "이 기기 삭제";
        del.textContent = "✕";
        del.addEventListener("click", (ev) => {
          ev.stopPropagation();
          deleteCustomDevice(device.id);
        });
        btn.appendChild(del);
      }

      li.appendChild(btn);
      el.deviceList.appendChild(li);
    });
  }

  function deleteCustomDevice(id) {
    if (!confirm("이 기기를 목록에서 삭제할까요?")) return;
    const remaining = loadCustomDevices().filter((d) => d.id !== id);
    saveCustomDevices(remaining);
    if (currentDeviceId === id) {
      currentDeviceId = null;
      showEmptyDossier();
      clearOrganHighlights();
      el.bodyStage.classList.remove("has-device", "zoomed");
    }
    renderDeviceList();
  }

  /* ------------------------------------------------------------------ */
  /* 기관 범례 렌더링                                                     */
  /* ------------------------------------------------------------------ */
  function renderOrganLegend() {
    el.organLegend.innerHTML = "";
    Object.keys(ORGAN_META).forEach((organId) => {
      const meta = ORGAN_META[organId];
      const btn = document.createElement("button");
      btn.type = "button";
      btn.dataset.organ = organId;
      btn.innerHTML = '<span class="dot"></span>' + escapeHtml(meta.label);
      btn.addEventListener("click", () => showOrganInfo(organId));
      el.organLegend.appendChild(btn);
    });
  }

  function showOrganInfo(organId) {
    const meta = ORGAN_META[organId];
    if (!meta) return;
    el.organHint.textContent = meta.label + " — " + meta.desc;

    // 기기가 선택되지 않은 상태에서 기관을 눌러도 살짝 하이라이트만 해준다.
    if (!currentDeviceId) {
      clearOrganHighlights();
      const group = el.bodyStage.querySelector('.organ[data-organ="' + organId + '"]');
      if (group) group.classList.add("active");
      const legendBtn = el.organLegend.querySelector('button[data-organ="' + organId + '"]');
      if (legendBtn) legendBtn.classList.add("active");
    }
  }

  /* ------------------------------------------------------------------ */
  /* 기기 선택                                                            */
  /* ------------------------------------------------------------------ */
  function selectDevice(id) {
    const device = findDevice(id);
    if (!device) return;

    currentDeviceId = id;
    seqIndex = 0;
    stopAutoplay();
    renderDeviceList();
    showDossier(device);
    renderCompare(device);
    renderSequential(device);
    applyMode();
  }

  function showEmptyDossier() {
    el.dossierEmpty.hidden = false;
    el.dossierContent.hidden = true;
  }

  function showDossier(device) {
    el.dossierEmpty.hidden = true;
    el.dossierContent.hidden = false;
    el.deviceTitle.textContent = (device.emoji ? device.emoji + " " : "") + device.name;
    el.deviceCategory.textContent = device.category || "기타";
  }

  /* ------------------------------------------------------------------ */
  /* 동시 비교 모드                                                       */
  /* ------------------------------------------------------------------ */
  function renderCompare(device) {
    el.textAd.textContent = device.adClaim || "";
    el.textReal.textContent = device.realMechanism || "";
    el.textWarn.textContent = device.sideEffects || "";
  }

  /* ------------------------------------------------------------------ */
  /* 순차 재생 모드                                                       */
  /* ------------------------------------------------------------------ */
  const TYPE_LABEL = { ad: "광고 주장", real: "실제 기전", warning: "한계 · 부작용", summary: "결론" };

  function renderSequential(device) {
    const seq = device.sequence && device.sequence.length ? device.sequence : buildFallbackSequence(device);
    device.__seq = seq; // 캐시

    el.seqTotal.textContent = seq.length;
    el.seqDots.innerHTML = "";
    seq.forEach((_, i) => {
      const dot = document.createElement("button");
      dot.type = "button";
      dot.setAttribute("aria-label", (i + 1) + "번째 단계");
      dot.addEventListener("click", () => {
        seqIndex = i;
        showSequentialStage(device);
      });
      el.seqDots.appendChild(dot);
    });

    showSequentialStage(device);
  }

  function buildFallbackSequence(device) {
    return [
      { stage: "광고 주장", organ: null, type: "ad", text: device.adClaim },
      { stage: "체내 유입", organ: device.targetOrgan, type: "real", text: "성분이 체내로 들어가 " + (ORGAN_META[device.targetOrgan] ? ORGAN_META[device.targetOrgan].label : "표적 기관") + "에 도달합니다." },
      { stage: "실제 기전", organ: device.targetOrgan, type: "real", text: device.realMechanism },
      { stage: "한계 · 부작용", organ: device.targetOrgan, type: "warning", text: device.sideEffects },
      { stage: "결론", organ: null, type: "summary", text: "광고 문구와 실제 인체 반응 사이에는 정도의 차이가 있습니다." },
    ];
  }

  function showSequentialStage(device) {
    const seq = device.__seq;
    if (!seq || !seq.length) return;
    seqIndex = Math.max(0, Math.min(seqIndex, seq.length - 1));
    const stage = seq[seqIndex];

    el.seqIndex.textContent = seqIndex + 1;
    el.seqType.textContent = TYPE_LABEL[stage.type] || stage.stage;
    el.seqType.className = "seq-type" + (stage.type ? " tone-" + stage.type : "");
    el.seqLabel.textContent = stage.stage;
    el.seqText.textContent = stage.text || "";

    Array.from(el.seqDots.children).forEach((dot, i) => dot.classList.toggle("active", i === seqIndex));

    if (stage.organ) {
      highlightOrgan(stage.organ, stage.type, true);
      playFx(device.animationType || "pulse", stage.organ, stage.type);
    } else {
      clearOrganHighlights();
      el.bodyStage.classList.remove("zoomed");
    }
  }

  function stepSequential(delta) {
    const device = findDevice(currentDeviceId);
    if (!device || !device.__seq) return;
    seqIndex = (seqIndex + delta + device.__seq.length) % device.__seq.length;
    showSequentialStage(device);
  }

  function stopAutoplay() {
    if (seqTimer) {
      clearInterval(seqTimer);
      seqTimer = null;
    }
    el.seqPlay.classList.remove("playing");
    el.seqPlay.textContent = "▶ 자동재생";
  }

  function toggleAutoplay() {
    if (seqTimer) {
      stopAutoplay();
      return;
    }
    el.seqPlay.classList.add("playing");
    el.seqPlay.textContent = "⏸ 정지";
    seqTimer = setInterval(() => stepSequential(1), SEQ_AUTOPLAY_MS);
  }

  /* ------------------------------------------------------------------ */
  /* 모드 전환                                                            */
  /* ------------------------------------------------------------------ */
  function applyMode() {
    const isCompare = currentMode === "compare";
    el.panelCompare.hidden = !isCompare;
    el.panelSequential.hidden = isCompare;
    el.modeBtns.forEach((btn) => {
      const active = btn.dataset.mode === currentMode;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-selected", active ? "true" : "false");
    });

    const device = findDevice(currentDeviceId);
    if (!device) return;

    if (isCompare) {
      stopAutoplay();
      clearOrganHighlights();
      highlightOrgan(device.targetOrgan, "real", false);
    } else {
      showSequentialStage(device);
    }
  }

  /* ------------------------------------------------------------------ */
  /* 인체 도해: 하이라이트 & 줌                                            */
  /* ------------------------------------------------------------------ */
  function clearOrganHighlights() {
    el.bodyStage.querySelectorAll(".organ").forEach((g) => g.classList.remove("active", "tone-ad", "tone-warning", "tone-real"));
    el.organLegend.querySelectorAll("button").forEach((b) => b.classList.remove("active", "tone-ad", "tone-warning", "tone-real"));
  }

  function highlightOrgan(organId, type, zoom) {
    clearOrganHighlights();
    el.bodyStage.classList.add("has-device");

    const group = el.bodyStage.querySelector('.organ[data-organ="' + organId + '"]');
    const legendBtn = el.organLegend.querySelector('button[data-organ="' + organId + '"]');
    const toneClass = type === "ad" ? "tone-ad" : type === "warning" ? "tone-warning" : "";

    if (group) {
      group.classList.add("active");
      if (toneClass) group.classList.add(toneClass);
    }
    if (legendBtn) {
      legendBtn.classList.add("active");
      if (toneClass) legendBtn.classList.add(toneClass);
    }

    const meta = ORGAN_META[organId];
    if (meta) {
      el.organHint.textContent = meta.label + " — " + meta.desc;
      if (zoom) {
        document.getElementById("anatomy").style.transformOrigin = meta.origin;
        el.bodyStage.classList.add("zoomed");
      } else {
        el.bodyStage.classList.remove("zoomed");
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* 상세 애니메이션 (fx)                                                  */
  /* ------------------------------------------------------------------ */
  function organFxPosition(organId) {
    // 실제 화면에 렌더링된 기관의 위치를 그대로 읽어온다.
    // (확대/축소 transform 이 걸려 있어도 getBoundingClientRect 는
    //  변환이 반영된 실제 화면 좌표를 반환하므로 별도 보정이 필요 없다.)
    const group = el.bodyStage.querySelector('.organ[data-organ="' + organId + '"]');
    const stageRect = el.bodyStage.getBoundingClientRect();
    if (!group || !stageRect.width) return { xPct: 50, yPct: 50 };
    const rect = group.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    return {
      xPct: ((cx - stageRect.left) / stageRect.width) * 100,
      yPct: ((cy - stageRect.top) / stageRect.height) * 100,
    };
  }

  function playFx(animationType, organId, type) {
    el.detailFx.innerHTML = "";
    const pos = organFxPosition(organId);
    const xPct = pos.xPct;
    const yPct = pos.yPct;

    if (animationType === "wave") {
      for (let i = 0; i < 3; i++) {
        const ring = document.createElement("div");
        ring.className = "fx-ring";
        ring.style.left = xPct + "%";
        ring.style.top = yPct + "%";
        ring.style.width = "60px";
        ring.style.height = "60px";
        ring.style.marginLeft = "-30px";
        ring.style.marginTop = "-30px";
        ring.style.animationDelay = i * 0.35 + "s";
        el.detailFx.appendChild(ring);
      }
    } else if (animationType === "ferment") {
      for (let i = 0; i < 8; i++) {
        const bubble = document.createElement("div");
        bubble.className = "fx-bubble";
        bubble.style.left = xPct - 8 + Math.random() * 16 + "%";
        bubble.style.bottom = 100 - yPct + "%";
        bubble.style.animationDelay = Math.random() * 1.2 + "s";
        el.detailFx.appendChild(bubble);
      }
    } else if (animationType === "receptor") {
      const molecule = document.createElement("div");
      molecule.className = "fx-molecule";
      molecule.style.left = xPct + "%";
      molecule.style.top = yPct + "%";
      el.detailFx.appendChild(molecule);
    } else {
      const pulse = document.createElement("div");
      pulse.className = "fx-pulse";
      pulse.style.left = xPct + "%";
      pulse.style.top = yPct + "%";
      if (type === "warning") pulse.style.background = "var(--warn-red)";
      else if (type === "real") pulse.style.background = "var(--real-teal)";
      el.detailFx.appendChild(pulse);
    }

    // 애니메이션이 끝난 요소들은 자동으로 정리
    setTimeout(() => {
      el.detailFx.innerHTML = "";
    }, 2700);
  }

  /* ------------------------------------------------------------------ */
  /* 새 기기 추가 모달                                                    */
  /* ------------------------------------------------------------------ */
  function openAddModal() {
    el.formAdd.reset();
    el.modalAdd.hidden = false;
    setTimeout(() => $("#f-name").focus(), 0);
  }

  function closeAddModal() {
    el.modalAdd.hidden = true;
  }

  function slugify(name) {
    const base = name
      .trim()
      .toLowerCase()
      .replace(/[^\w가-힣]+/g, "-")
      .replace(/^-+|-+$/g, "");
    return (base || "device") + "-" + Date.now().toString(36);
  }

  function handleAddSubmit(ev) {
    ev.preventDefault();
    const name = $("#f-name").value.trim();
    const emoji = $("#f-emoji").value.trim() || "🧪";
    const category = $("#f-category").value;
    const targetOrgan = $("#f-organ").value;
    const animationType = $("#f-anim").value;
    const adClaim = $("#f-ad").value.trim();
    const realMechanism = $("#f-real").value.trim();
    const sideEffects = $("#f-warn").value.trim();

    if (!name || !adClaim || !realMechanism) return;

    const device = {
      id: slugify(name),
      name,
      emoji,
      category,
      targetOrgan,
      animationType,
      adClaim,
      realMechanism,
      sideEffects,
      sequence: [
        { stage: "광고 주장", organ: null, type: "ad", text: adClaim },
        { stage: "체내 유입", organ: targetOrgan, type: "real", text: "성분이 체내로 들어가 " + (ORGAN_META[targetOrgan] ? ORGAN_META[targetOrgan].label : "표적 기관") + "에 도달합니다." },
        { stage: "실제 기전", organ: targetOrgan, type: "real", text: realMechanism },
        { stage: "한계 · 부작용", organ: targetOrgan, type: "warning", text: sideEffects || "아직 등록된 부작용 정보가 없습니다." },
        { stage: "결론", organ: null, type: "summary", text: "광고 문구와 실제 인체 반응 사이의 차이를 직접 비교해보세요." },
      ],
    };

    const customs = loadCustomDevices();
    customs.push(device);
    saveCustomDevices(customs);

    closeAddModal();
    renderDeviceList();
    selectDevice(device.id);
  }

  /* ------------------------------------------------------------------ */
  /* 내보내기 / 불러오기                                                   */
  /* ------------------------------------------------------------------ */
  function exportCustomDevices() {
    const customs = loadCustomDevices();
    if (!customs.length) {
      alert("아직 직접 추가한 기기가 없어요. '+ 새 기기 추가'로 먼저 등록해보세요.");
      return;
    }
    const blob = new Blob([JSON.stringify(customs, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "내가-추가한-기기.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function importCustomDevicesFromFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const incoming = JSON.parse(String(reader.result));
        if (!Array.isArray(incoming)) throw new Error("배열 형식이 아닙니다.");

        const existing = loadCustomDevices();
        const existingIds = new Set(existing.map((d) => d.id));
        let added = 0;

        incoming.forEach((device) => {
          if (!device || !device.name || !device.adClaim || !device.realMechanism) return;
          if (existingIds.has(device.id)) {
            device.id = slugify(device.name); // id 충돌 방지
          }
          existing.push(device);
          existingIds.add(device.id);
          added++;
        });

        saveCustomDevices(existing);
        renderDeviceList();
        alert(added + "개의 기기를 불러왔어요.");
      } catch (e) {
        alert("파일을 읽는 중 문제가 발생했어요. 이 시뮬레이터에서 내보낸 JSON 파일인지 확인해주세요.");
        console.warn(e);
      }
    };
    reader.readAsText(file);
  }

  /* ------------------------------------------------------------------ */
  /* 유틸                                                                */
  /* ------------------------------------------------------------------ */
  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[c]));
  }

  /* ------------------------------------------------------------------ */
  /* 이벤트 바인딩                                                        */
  /* ------------------------------------------------------------------ */
  function bindEvents() {
    // 인체 도해 위 기관 클릭
    el.bodyStage.querySelectorAll(".organ").forEach((group) => {
      group.addEventListener("click", () => showOrganInfo(group.dataset.organ));
    });

    // 모드 전환
    el.modeBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        currentMode = btn.dataset.mode;
        applyMode();
      });
    });

    // 순차재생 컨트롤
    el.seqPrev.addEventListener("click", () => {
      stopAutoplay();
      stepSequential(-1);
    });
    el.seqNext.addEventListener("click", () => {
      stopAutoplay();
      stepSequential(1);
    });
    el.seqPlay.addEventListener("click", toggleAutoplay);

    // 기기 추가 모달
    el.btnAddDevice.addEventListener("click", openAddModal);
    el.btnCancelAdd.addEventListener("click", closeAddModal);
    el.formAdd.addEventListener("submit", handleAddSubmit);
    el.modalAdd.addEventListener("click", (ev) => {
      if (ev.target === el.modalAdd) closeAddModal();
    });

    // 내보내기 / 불러오기
    el.btnExport.addEventListener("click", exportCustomDevices);
    el.btnImport.addEventListener("click", () => el.fileImport.click());
    el.fileImport.addEventListener("change", () => {
      const file = el.fileImport.files && el.fileImport.files[0];
      if (file) importCustomDevicesFromFile(file);
      el.fileImport.value = "";
    });

    // 사용법 모달
    el.btnIntro.addEventListener("click", () => (el.modalIntro.hidden = false));
    el.btnCloseIntro.addEventListener("click", () => (el.modalIntro.hidden = true));
    el.modalIntro.addEventListener("click", (ev) => {
      if (ev.target === el.modalIntro) el.modalIntro.hidden = true;
    });

    // Esc 로 모달 닫기
    document.addEventListener("keydown", (ev) => {
      if (ev.key !== "Escape") return;
      if (!el.modalAdd.hidden) closeAddModal();
      if (!el.modalIntro.hidden) el.modalIntro.hidden = true;
    });
  }

  /* ------------------------------------------------------------------ */
  /* 초기화                                                               */
  /* ------------------------------------------------------------------ */
  function init() {
    renderOrganLegend();
    renderDeviceList();
    bindEvents();

    // 처음 방문한 친구를 위해 사용법을 한 번 보여준다
    if (!localStorage.getItem("bam_introSeen")) {
      el.modalIntro.hidden = false;
      try {
        localStorage.setItem("bam_introSeen", "1");
      } catch (e) {
        /* localStorage 를 못 쓰는 환경이면 그냥 넘어간다 */
      }
    }
  }

  init();
})();
